# بوت منة سليمان — n8n + Gemini + قاعدة معرفة فقط

هذا هو المطلوب الحقيقي: **خدمة خلفية** وليست واجهة محادثة. n8n يستقبل رسالة العميل من القناة الرسمية، يرسلها للخدمة، والخدمة تبحث في الأسئلة والأجوبة التي تضيفينها فقط ثم تطلب من Gemini صياغة رد من هذه المعلومات حصراً.

## أمان مهم جداً

المفتاح الذي أُرسل في المحادثة صار مكشوفاً. ألغيه الآن من Google AI Studio وأنشئي مفتاحاً جديداً مقيداً لـGemini API. لا تضعيه في GitHub أو في n8n workflow أو في واجهة موقع.

ضعي المفتاح الجديد فقط على الخادم في `.env`:

```env
GEMINI_API_KEY=ضع_المفتاح_الجديد_هنا
ADMIN_TOKEN=كلمة_مرور_إدارة_طويلة
N8N_WEBHOOK_SECRET=سر_بين_n8n_والخدمة
```

Gemini توصي بتخزين المفتاح في متغير بيئة. [التوثيق الرسمي](https://ai.google.dev/gemini-api/docs/api-key).

## التشغيل

```bash
cp .env.example .env
npm install
npm start
```

الخادم يعمل على `http://localhost:3000`، ولا يصلح ليستقبل رسائل المنصات قبل وضعه على رابط HTTPS عام.

## إضافة الأسئلة والأجوبة

الملف الوحيد المرجعي هو `data/knowledge-base.json`.

كل عنصر هكذا:

```json
{
  "id": "price-1",
  "question": "سعر خدمة كذا؟",
  "answer": "سعر خدمة كذا هو ...",
  "tags": ["سعر", "خدمة كذا"]
}
```

يمكن أيضاً الإدارة عبر API محمي:

```bash
curl -H "Authorization: Bearer ADMIN_TOKEN" http://localhost:3000/admin/knowledge
```

لا ترسل إلى Gemini قاعدة المعرفة كاملة؛ الكود يستخرج فقط العناصر الأكثر صلة برسالة العميل، ثم يفرض في التعليمات ألا يجيب إلا منها. إن لم يجد معلومة يرد بالتصعيد للفريق بدلاً من الاختراع.

## ربط n8n

1. افتحي n8n ثم Import from File.
2. اختاري `workflows/menna-knowledge-only-bot.json`.
3. في متغيرات n8n أضيفي:
   - `BOT_BACKEND_URL`: رابط الخادم العام، مثال `https://bot.example.com`
   - `N8N_WEBHOOK_SECRET`: نفس السر المكتوب في `.env`.
4. فعّلي الـworkflow. رابط n8n الناتج هو نقطة استقبال الرسائل.
5. وصّلي Trigger رسمي من Meta Messenger أو Instagram إلى الـworkflow، ثم بعد خطوة **Knowledge-only Gemini** أضيفي عقدة الإرسال الرسمية للقناة لتبعث القيمة `reply` للعميل.

الـworkflow الحالي يعيد JSON للاختبار، ولا يدعي إرسال رسائل للمنصات من غير صلاحياتها الرسمية.

## اختبار قبل ربط أي منصة

```bash
curl -X POST http://localhost:3000/webhook/customer-message \
  -H "Content-Type: application/json" \
  -H "x-webhook-secret: N8N_WEBHOOK_SECRET" \
  -d '{"senderId":"test-1","text":"ما هي الاستشارة الأولية؟","channel":"test"}'
```

## ما لن يفعله البوت

- لا يضع مفتاح Gemini في صفحة عامة أو GitHub.
- لا يخترع إجابات خارج ملف المعرفة.
- لا يستخدم scraping أو أي التفاف على سياسات Facebook/Instagram/TikTok.
- لا يرسل تلقائياً لأي منصة قبل إعداد الربط والموافقة الرسمية.
