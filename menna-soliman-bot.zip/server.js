import express from 'express';
import { DatabaseSync } from 'node:sqlite';
import dotenv from 'dotenv';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const cfg = {
  port: Number(process.env.PORT || 3000), baseUrl: process.env.BASE_URL || 'http://localhost:3000',
  adminToken: process.env.ADMIN_TOKEN || 'demo-admin', demo: process.env.DEMO_MODE !== 'false',
  verifyToken: process.env.META_VERIFY_TOKEN || '', appSecret: process.env.META_APP_SECRET || '',
  pageToken: process.env.META_PAGE_ACCESS_TOKEN || '',
  numbers: (process.env.WHATSAPP_NUMBERS || '201000000001,201000000002,201000000003').split(',').map(x => x.replace(/\D/g, '')).filter(Boolean)
};
const db = new DatabaseSync(process.env.DB_FILE || path.join(__dirname, 'data', 'menna-bot.db'));
db.exec('PRAGMA journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS services (id INTEGER PRIMARY KEY, name TEXT UNIQUE, description TEXT, price TEXT, keywords TEXT, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS leads (id INTEGER PRIMARY KEY, channel TEXT, external_id TEXT, name TEXT, phone TEXT, need TEXT, stage TEXT DEFAULT 'جديد', assigned_number TEXT, opt_in INTEGER DEFAULT 0, last_inbound_at TEXT, last_outbound_at TEXT, followup_sent_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(channel, external_id));
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, lead_id INTEGER, direction TEXT, text TEXT, provider_message_id TEXT UNIQUE, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
INSERT OR IGNORE INTO settings(key,value) VALUES ('rr_cursor','0'),('followup_enabled','true'),('followup_hours','24');
INSERT OR IGNORE INTO services(name,description,price,keywords) VALUES ('استشارة أولية','جلسة تعريفية لفهم الاحتياج وتحديد الخطوة المناسبة','يُحدد بعد التواصل','استشارة حجز موعد مقابلة'),('خدمة مميزة','خدمة مخصصة حسب الاحتياج مع متابعة مباشرة','يُحدد بعد التواصل','خدمة باقة متابعة');`);
app.use('/webhooks/meta', express.raw({ type: 'application/json' }));
app.use(express.json()); app.use(express.static(path.join(__dirname, 'public')));
const now = () => new Date().toISOString();
const admin = (req,res,next) => req.get('x-admin-token') === cfg.adminToken ? next() : res.status(401).json({error:'غير مصرح'});
function services() { return db.prepare('SELECT * FROM services WHERE active=1').all(); }
function findService(text) { const s=services(); const q=text.toLowerCase(); return s.find(x => x.keywords.split(/[,، ]+/).some(k => k && q.includes(k.toLowerCase()))) || null; }
function upsertLead({channel, externalId, name='عميل', phone=null}) { let lead=db.prepare('SELECT * FROM leads WHERE channel=? AND external_id=?').get(channel,externalId); if(!lead){ db.prepare('INSERT INTO leads(channel,external_id,name,phone,last_inbound_at) VALUES(?,?,?,?,?)').run(channel,externalId,name,phone,now()); lead=db.prepare('SELECT * FROM leads WHERE channel=? AND external_id=?').get(channel,externalId); } return lead; }
function saveMessage(leadId, direction, text, providerId=null) { try { db.prepare('INSERT INTO messages(lead_id,direction,text,provider_message_id) VALUES(?,?,?,?)').run(leadId,direction,text,providerId); } catch { return false; } return true; }
function chooseNumber(lead) { if (lead.assigned_number) return lead.assigned_number; if (!cfg.numbers.length) return null; const cursor=Number(db.prepare("SELECT value FROM settings WHERE key='rr_cursor'").get().value||0); const number=cfg.numbers[cursor % cfg.numbers.length]; db.prepare("UPDATE settings SET value=? WHERE key='rr_cursor'").run(String((cursor+1)%cfg.numbers.length)); db.prepare('UPDATE leads SET assigned_number=? WHERE id=?').run(number,lead.id); return number; }
function waLink(lead) { const number=chooseNumber(lead); if(!number) return null; const summary=`مرحباً، أنا ${lead.name}. جاي من ${lead.channel}. احتياجي: ${lead.need || 'لم يُحدد بعد'}. رقم الطلب: #${lead.id}`; return `https://wa.me/${number}?text=${encodeURIComponent(summary)}`; }
function answer(text, lead) { const svc=findService(text); if(svc) { db.prepare('UPDATE leads SET need=?, stage=?, last_inbound_at=? WHERE id=?').run(svc.name,'مؤهل',now(),lead.id); return `أهلاً بيك 🌷 خدمة «${svc.name}»: ${svc.description}${svc.price ? `\nالسعر: ${svc.price}` : ''}\nتحبي أرتب لك تواصل سريع مع الفريق؟`; }
 const asked = /واتساب|تواصل|رقم|موظف|بشري/.test(text); if(asked || lead.need) { const link=waLink(lead); return link ? `أكيد، ده رابط واتساب مباشر للفريق ومعاه ملخص طلبك تلقائياً:\n${link}` : 'ممكن تكتبي لنا وسيلة التواصل المناسبة؟'; }
 return `أهلاً بيك يا ${lead.name} 🌷 أنا مساعد منة سليمان. قولي محتاجة أي خدمة؟\nالخدمات المتاحة: ${services().map(s=>s.name).join('، ')}.`;
}
async function sendMeta(psid, text) { if(cfg.demo || !cfg.pageToken) return {demo:true}; const r=await fetch(`https://graph.facebook.com/v22.0/me/messages?access_token=${encodeURIComponent(cfg.pageToken)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({recipient:{id:psid},messaging_type:'RESPONSE',message:{text}})}); if(!r.ok) throw new Error(await r.text()); return r.json(); }
async function receive({channel, externalId, name, text, providerId}) { const lead=upsertLead({channel,externalId,name}); if(!saveMessage(lead.id,'in',text,providerId)) return null; db.prepare('UPDATE leads SET last_inbound_at=?, followup_sent_at=NULL WHERE id=?').run(now(),lead.id); const reply=answer(text,lead); saveMessage(lead.id,'out',reply); db.prepare('UPDATE leads SET last_outbound_at=? WHERE id=?').run(now(),lead.id); return {lead:db.prepare('SELECT * FROM leads WHERE id=?').get(lead.id),reply}; }
// Meta webhook: use the same endpoint for Messenger and Instagram. Signature check is mandatory when secret exists.
app.get('/webhooks/meta',(req,res)=>{ const q=req.query; if(q['hub.mode']==='subscribe' && q['hub.verify_token']===cfg.verifyToken) return res.status(200).send(q['hub.challenge']); return res.sendStatus(403); });
app.post('/webhooks/meta', async (req,res)=>{ const raw=req.body; const signature=req.get('x-hub-signature-256'); if(cfg.appSecret){ const expected='sha256='+crypto.createHmac('sha256',cfg.appSecret).update(raw).digest('hex'); if(!signature || !crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))) return res.sendStatus(403); } res.sendStatus(200); try { const body=JSON.parse(raw.toString()); for(const entry of body.entry||[]) for(const event of entry.messaging||[]) { if(!event.message?.text || event.message.is_echo) continue; const result=await receive({channel:body.object==='instagram'?'instagram':'messenger',externalId:event.sender.id,name:'عميل',text:event.message.text,providerId:event.message.mid}); if(result) await sendMeta(event.sender.id,result.reply); } } catch(e){ console.error('Webhook error:',e.message); } });
app.post('/api/demo/message', async (req,res)=>{ const {channel='demo',customerId='demo-1',name='عميل تجريبي',text}=req.body; if(!text) return res.status(400).json({error:'النص مطلوب'}); const r=await receive({channel,externalId:customerId,name,text,providerId:`demo-${Date.now()}`}); res.json({...r, whatsappUrl:waLink(r.lead)}); });
app.get('/api/health',(req,res)=>res.json({ok:true,demo:cfg.demo,channels:{messenger:!!cfg.pageToken,instagram:!!cfg.pageToken,tiktok:'manual/partner only'}}));
app.get('/api/services',admin,(req,res)=>res.json(services()));
app.post('/api/services',admin,(req,res)=>{ const {name,description='',price='',keywords=''}=req.body; if(!name) return res.status(400).json({error:'اسم الخدمة مطلوب'}); const r=db.prepare('INSERT INTO services(name,description,price,keywords) VALUES(?,?,?,?)').run(name,description,price,keywords); res.json({id:r.lastInsertRowid}); });
app.delete('/api/services/:id',admin,(req,res)=>{db.prepare('UPDATE services SET active=0 WHERE id=?').run(req.params.id);res.sendStatus(204);});
app.get('/api/leads',admin,(req,res)=>res.json(db.prepare('SELECT * FROM leads ORDER BY id DESC').all()));
app.get('/api/leads/:id/messages',admin,(req,res)=>res.json(db.prepare('SELECT * FROM messages WHERE lead_id=? ORDER BY id').all(req.params.id)));
app.patch('/api/leads/:id',admin,(req,res)=>{ const fields=['stage','phone','need','opt_in']; const updates=fields.filter(k=>k in req.body); if(!updates.length)return res.sendStatus(204); db.prepare(`UPDATE leads SET ${updates.map(k=>`${k}=?`).join(',')} WHERE id=?`).run(...updates.map(k=>req.body[k]),req.params.id);res.sendStatus(204);});
app.get('/api/settings',admin,(req,res)=>res.json({settings:Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value])),config:{demo:cfg.demo,numbers:cfg.numbers.map(n=>n.slice(0,4)+'••••'+n.slice(-3))}}));
app.post('/api/settings',admin,(req,res)=>{ for(const [key,value] of Object.entries(req.body)) db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key,String(value));res.sendStatus(204);});
// Run every 10 minutes. It never sends an unsolicited platform message: only leads opted in and inside the allowed conversation window should be sent through each official channel adapter.
setInterval(()=>{ const on=db.prepare("SELECT value FROM settings WHERE key='followup_enabled'").get().value==='true'; const hours=Number(db.prepare("SELECT value FROM settings WHERE key='followup_hours'").get().value||24); if(!on)return; const rows=db.prepare("SELECT * FROM leads WHERE opt_in=1 AND last_inbound_at IS NOT NULL AND followup_sent_at IS NULL AND datetime(last_inbound_at) < datetime('now', ?) ").all(`-${hours} hours`); for(const lead of rows){ const msg='حابين نطمن هل ما زلتي محتاجة مساعدة؟ لو لا، تجاهلي الرسالة ولن نتابع.'; saveMessage(lead.id,'out',msg); db.prepare('UPDATE leads SET followup_sent_at=?,last_outbound_at=? WHERE id=?').run(now(),now(),lead.id); console.log(`Follow-up queued for #${lead.id}; connect the approved channel sender before production.`); } }, 10*60*1000);
app.listen(cfg.port,()=>console.log(`Menna bot running on ${cfg.baseUrl} (port ${cfg.port}), demo=${cfg.demo}`));


